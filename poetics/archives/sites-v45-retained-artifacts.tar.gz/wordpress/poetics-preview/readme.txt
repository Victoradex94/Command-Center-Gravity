Poetics Private Preview 0.1.0

Install via Plugins > Add New > Upload Plugin, then activate.
Open the Poetics Preview admin menu while signed in as an editor or administrator.
Optional: insert [poetics_preview] into a draft page or Elementor Shortcode widget.
The preview endpoint and all bundled assets require edit_pages capability.
This plugin creates no pages, changes no theme settings, and adds no database tables.
It does not publish publicly or implement server-side submissions.
Deactivate to remove the admin menu and preview handler. Existing local game progress remains in browser storage.
Includes the current prototype assets; state geometry attribution remains visible in the Atlas.
This is an initial preview adapter, not the completed editorial CMS migration.
PHP lint and live WordPress testing remain required before activation.
