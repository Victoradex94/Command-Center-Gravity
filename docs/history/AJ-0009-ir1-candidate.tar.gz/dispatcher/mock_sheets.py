"""Persistent LOCAL fault fixture. No networking, Google API, or live credentials."""

from dataclasses import asdict
from contextlib import closing, contextmanager
import json
import sqlite3

from .model import AGENT_JOB_COLUMNS, require
from .sheets_writer import (Authority, CurrentRow, Effect, Observation, SheetsWriter,
                            Snapshot, Submission)


class SimulatedCrash(BaseException):
    """Bypasses the writer's Exception handler like abrupt process loss."""


class MockAuthority:
    def __init__(self):
        self.states: dict[str, str] = {}

    def inspect(self, reference: str, scope: str, actor: str) -> Authority:
        return Authority(reference, scope, actor, self.states.get(reference, "valid"),
                         True, "LOCAL fixture authority attestation")


class MockSheets:
    """Separate SQLite file survives writer restart; stronger than real Sheets.

    Local transactions provide atomic mock row apply and provider operation log.
    A live adapter cannot infer these guarantees from this fixture's behavior.
    Fault plans, resolve(), seed(), and set_columns() are test controls only.
    """

    MODES = {"apply", "reject", "tool-noop", "tool-pending", "human-noop",
             "denied-noop", "partial", "apply-timeout", "apply-crash", "before-crash"}

    def __init__(self, path: str, scope: str):
        self.path, self.scope = path, scope
        with self._connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS fixture (id INTEGER PRIMARY KEY, body TEXT NOT NULL)")
            existing = db.execute("SELECT body FROM fixture WHERE id=1").fetchone()
            if existing:
                require(json.loads(existing[0])["scope"] == scope, "mock scope mismatch")
            else:
                self._save(db, {"scope": scope, "columns": AGENT_JOB_COLUMNS,
                                "rows": [], "operations": {}, "plans": [], "calls": []})

    @contextmanager
    def _connect(self):
        with closing(sqlite3.connect(self.path, timeout=10)) as db:
            db.execute("PRAGMA synchronous=FULL")
            with db:
                yield db

    @staticmethod
    def _load(db):
        return json.loads(db.execute("SELECT body FROM fixture WHERE id=1").fetchone()[0])

    @staticmethod
    def _save(db, data):
        db.execute("INSERT OR REPLACE INTO fixture VALUES (1, ?)", (json.dumps(data),))

    def plan(self, *modes: str) -> None:
        require(all(m in self.MODES for m in modes), "unknown mock fault")
        with self._connect() as db:
            data = self._load(db)
            data["plans"].extend(modes)
            self._save(db, data)

    def seed(self, rows: tuple[CurrentRow, ...]) -> None:
        with self._connect() as db:
            data = self._load(db)
            data["rows"] = [asdict(r) for r in rows]
            self._save(db, data)

    def set_columns(self, columns) -> None:
        with self._connect() as db:
            data = self._load(db)
            data["columns"] = list(columns)
            self._save(db, data)

    @property
    def calls(self) -> list[dict]:
        with self._connect() as db:
            return self._load(db)["calls"]

    def snapshot(self, scope: str) -> Snapshot:
        require(scope == self.scope, "mock scope mismatch")
        with self._connect() as db:
            data = self._load(db)
        rows = tuple(CurrentRow(r["position"], tuple(r["cells"]), tuple(r["source_keys"])) for r in data["rows"])
        return Snapshot(scope, tuple(data["columns"]), rows, True, True, "LOCAL complete mock snapshot")

    @staticmethod
    def _apply(data, sub: Submission, partial=False):
        cells = list(sub.cells)
        if partial:
            cells[10] = "MOCK partial effect"
        data["rows"] = [r for r in data["rows"] if r["position"] != sub.position]
        data["rows"].append({"position": sub.position, "cells": cells, "source_keys": sub.source_keys})

    def submit(self, submission: Submission) -> None:
        sub = submission
        require(sub.scope == self.scope, "mock target mismatch")
        with self._connect() as db:
            db.execute("BEGIN IMMEDIATE")
            data = self._load(db)
            # No silent provider deduplication: an engine replay fails this fixture.
            require(sub.attempt_id not in data["operations"], "duplicate provider submit")
            mode = data["plans"].pop(0) if data["plans"] else "apply"
            data["calls"].append(asdict(sub))
            target = next((r for r in data["rows"] if r["position"] == sub.position), None)
            expected = json.loads(json.dumps(asdict(sub.before))) if sub.before else None
            if target != expected:
                mode = "reject"
            effect, settled, cancellation = Effect.UNKNOWN, False, "none"
            if mode in ("apply", "apply-timeout", "apply-crash"):
                self._apply(data, sub)
                effect, settled = Effect.APPLIED, True
            elif mode == "partial":
                self._apply(data, sub, partial=True)
                effect = Effect.PARTIAL
            elif mode in ("reject", "tool-noop", "human-noop", "denied-noop"):
                effect, settled = Effect.NOOP, True
            elif mode == "tool-pending":
                effect = Effect.ACTIVE
            cancellation = {"tool-noop": "tool", "tool-pending": "tool",
                            "human-noop": "human", "denied-noop": "denied"}.get(mode, "none")
            obs = Observation(sub.attempt_id, sub.digest, sub.scope, effect, settled, settled, True,
                              "LOCAL provider operation log; " + mode,
                              "cancelled-call" if cancellation != "none" else "provider-rejection",
                              cancellation=cancellation,
                              cancellation_authenticated=cancellation in ("human", "denied"))
            data["operations"][sub.attempt_id] = {"submission": asdict(sub), "observation": asdict(obs)}
            self._save(db, data)
        if mode in ("apply-crash", "before-crash"):
            raise SimulatedCrash(mode)
        if mode != "apply":
            raise TimeoutError("user cancelled MCP tool call" if cancellation != "none" else "LOCAL response lost")

    def inspect(self, submission: Submission) -> Observation:
        with self._connect() as db:
            item = self._load(db)["operations"].get(submission.attempt_id)
        if item is None:
            return Observation(submission.attempt_id, submission.digest, self.scope, Effect.UNKNOWN,
                               False, False, True, "LOCAL absent log is NOT proof of no-op")
        obs = dict(item["observation"])
        obs["effect"] = Effect(obs["effect"])
        return Observation(**obs)

    def resolve(self, attempt_id: str, effect: Effect) -> None:
        """Fixture-only authoritative settlement, including a simulated late apply."""
        require(effect in (Effect.APPLIED, Effect.NOOP, Effect.UNKNOWN, Effect.PARTIAL), "unsupported settlement")
        with self._connect() as db:
            data = self._load(db)
            item = data["operations"][attempt_id]
            previous = item["observation"]["effect"]
            require(previous in (Effect.ACTIVE, Effect.UNKNOWN), "cannot erase settled/partial effects")
            if effect == Effect.APPLIED:
                self._apply(data, SheetsWriter._submission(item["submission"]))
            obs = item["observation"]
            obs["effect"] = effect
            obs["settled"] = obs["effects_resolved"] = effect in (Effect.APPLIED, Effect.NOOP)
            obs["evidence"] = "LOCAL authoritative settlement; no outstanding effects"
            self._save(db, data)
